from flask import render_template, request
from app import app, host, port, user, passwd, db
from app.helpers.database import con_db, query_db
from app.helpers.filters import format_currency
import jinja2
import pymysql 
import re
# To create a database connection, add the following
# within your view functions:
# con = con_db(host, port, user, passwd, db)
#####################################################

import math
import cPickle as pickle
import numpy as np
from sklearn import linear_model
import csv
import json                   

#####################################################



@app.route('/home', methods=['GET','POST'])
def home():
        
	if request.method == 'POST':
                     
		myitem = request.form["itemdropdown"]
		mycond = request.form["conditiondropdown"]
                mybrand=request.form["branddropdown"]
                mycolor=request.form["colordropdown"]
                mymaterial=request.form["materialdropdown"]
		### all sorta analytics here
                if (myitem=="Category"):
	             return render_template('homeerror.html')
                else:
                
                  feature = {}
                  for key, val in csv.reader(open("/Users/adas/Desktop/Insight/insightfl/app/feature_all.csv",'rU')):
                      feature[str(key)] = val
                             
                  condition_code={}
                
                  condition_code["Good"]=2
                  condition_code["Vintage"]=5
                  condition_code["Like New"]=4
                  condition_code["New"]=6
                  condition_code["Excellent"]=3
                  condition_code["Fair"]=1
                  if myitem.lower()=="table":
                      model = pickle.load(open("/Users/adas/Desktop/Insight/insightfl/app/regrmodel_all_table", 'rb'))
                  elif myitem.lower()=="chair":
                      model = pickle.load(open("/Users/adas/Desktop/Insight/insightfl/app/regrmodel_all_chair", 'rb'))
                  elif myitem.lower()=="cabinet":
                      model = pickle.load(open("/Users/adas/Desktop/Insight/insightfl/app/regrmodel_all_cabinet", 'rb'))
                  elif myitem.lower()=="sofa":
                      model = pickle.load(open("/Users/adas/Desktop/Insight/insightfl/app/regrmodel_all_sofa", 'rb'))
                  elif myitem.lower()=="side table":
                      model = pickle.load(open("/Users/adas/Desktop/Insight/insightfl/app/regrmodel_all_side_table", 'rb'))
                  word={}
                
                  f=open("/Users/adas/Desktop/Insight/insightfl/app/"+myitem.lower()+"cloudcount.csv",'rU')
                  fread=f.readlines()
                  for line in fread: 
                      word[line.split(':')[0]]=line.split(':')[1].strip('\n')                  
                
                 
                  X=[0]*len(feature)
                  X[int(feature["Condition"])]=condition_code[str(mycond)]
               
                  if str(mybrand) !="None of the above":
                      X[int(feature[str(mybrand)])]=1
                  if str(mycolor) !="None of the above":
                      X[int(feature[str(mycolor)])]=1
                  if str(mymaterial) !="None of the above": 
                      X[int(feature[str(mymaterial)])]=1
                
                
                  result = int(model.predict(X))
                
                
                  if result<0:
                      result="WAIT TO SELL"
                                       
                  else:
                      result="PRICE YOUR "+ myitem.upper() +" AT OR BELOW $" +str(result) 
                  ############################################      
                  #    Create database connection
                  conn = pymysql.connect(host='127.0.0.1', port=3306, user='root', passwd='', 
                           db='Insight')
                  flagst=0
                  cur = conn.cursor()
                  cur.execute("""SELECT PRICE
                  FROM CRAIGSLIST
                  WHERE CATEGORY=%s
                  ;""",myitem)
                     
              
                  returned_data = cur.fetchall()
                
                  listd = list(returned_data)
                                
                  price=[] 
                 
                  for i in range(0, len(listd)):
                      price.append(float((listd[i][0])))
                         
                  
                
                  minp=min(price)
                  maxp=max(price)  
                  if myitem.lower()=="sofa":
                      bin_size=int((maxp-minp)/200)
                  else:  
                      bin_size=int((maxp-minp)/50)          
                
                  pr=np.array(price)
                  hist=np.histogram(pr,bins=bin_size)
                 
                  hist_data=[]
                
                  for i in range(0,bin_size):
                      if hist[0][i]>0:
                          x=hist[0][i]
                          y="$"+str(int(hist[1][i]))+"-"+"$"+str(int(hist[1][i+1]))
                          hist_data.append([y,x]) 
                
                
                  
                        
                  cur.execute("""SELECT CATEGORY, PRICE, COND, BRAND, MATERIAL, COLOR
                  FROM CRAIGSLIST
                  WHERE CATEGORY=%s AND COND=%s 
                  LIMIT 3
                  ;""",[myitem, mycond])
                  sql_data=cur.fetchall()
                               
                  list_sql=list(sql_data)
                 
                 
                                  
                  if len(list_sql)<2:
                      
                      cur.execute("""SELECT CATEGORY, PRICE, COND, BRAND, MATERIAL, COLOR
                      FROM CRAIGSLIST
                      WHERE CATEGORY=%s 
                      LIMIT 3
                      ;""",myitem)
                      sql_data=cur.fetchall()

                      list_sql=list(sql_data)
                     
                      
                  cur.close()
                  conn.close()

                
                  wordjson=[]
                  for keys,values in word.items():
                    temp={'text':keys, 'weight':values}
                    wordjson.append(temp)
 
               
	  	  return render_template('result.html',myitem=myitem.upper(),myresult=result,data=list_sql,histogram=hist_data,dict=json.dumps(wordjson))
    # Renders home.html.
	return render_template('home.html')

@app.route('/result')
def result():
    # Renders slides.html.
    return render_template('result.html')

@app.route('/slides')
def about():
    # Renders slides.html.
    return render_template('slides.html')


@app.route('/author')
def contact():
    # Renders author.html.
    return render_template('author.html')

@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('500.html'), 500
